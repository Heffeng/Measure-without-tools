package com.sixgo.measure.length.activity;

import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sixgo.measure.R;
import com.sixgo.measure.length.entries.Division_Selection;
import com.sixgo.measure.length.ui.InDialogView;
import com.sixgo.measure.length.ui.TipDialogView;
import com.sixgo.measure.length.utils.AnalyzeTools;
import com.sixgo.measure.length.utils.DialogTools;
import com.sixgo.measure.length.utils.ListTools;
import com.sixgo.measure.length.utils.SerializerTools;

public class LengthActivity extends Activity implements OnClickListener,
		android.content.DialogInterface.OnClickListener {
	private static final int PICTURE = 0;
	private static final int CAMERA = 1;
	private String[] items;
	private List<Division_Selection> selections;
	private Division_Selection selection;
	private TextView tv_division_select;
	private int position = 0;
	private AlertDialog inDialog;
	private InDialogView view;
	private int temp = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.activity_length);
		
		Builder builder = new Builder(this);
		builder.setTitle("提示ʾ").setView(new TipDialogView(this, null)).setPositiveButton("确定", this).show();
		
		Button btn_division_select = (Button) findViewById(R.id.btn_division_select);
		btn_division_select.setOnClickListener(this);
		ImageButton ib_division_file = (ImageButton) findViewById(R.id.ib_division_file);
		ib_division_file.setOnClickListener(this);
		ImageButton ib_division_camera = (ImageButton) findViewById(R.id.ib_division_camera);
		ib_division_camera.setOnClickListener(this);
		tv_division_select = (TextView) findViewById(R.id.tv_division_select);

		selections = AnalyzeTools.analyzeSelectionFromXml(this);// 从xml文件中解析出选项

		// 用于回显数据，拿到上次用户的选择
		SharedPreferences sp = getPreferences(MODE_PRIVATE);
		position = (int) sp.getLong("position", 0);// 拿到上次的position
		if (position >= selections.size()) {
			position = 0;// 如果用户把文件删除，那么可能会有position>选项数量的情况
			// 出现这种情况，要把position信息重置。
		}
		temp = position; // 如果用户在第一个对话框没有选择就去点击确定，temp=0;所以要在开始就使temp=position

		tv_division_select.setText(selections.get(position).toString());// 设置TextView的内容
		selection = selections.get(position);
	}

	/**
	 * 在activity销毁时保存用户的选择
	 */
	@Override
	protected void onDestroy() {
		SharedPreferences sp = this.getPreferences(MODE_PRIVATE);
		Editor edit = sp.edit();
		edit.putLong("position", position);
		edit.commit();
		super.onDestroy();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == PICTURE) {
			if (data == null)
				return;
			Uri selectedImage = data.getData();
			String[] filePathColumns = { MediaStore.Images.Media.DATA };
			Cursor c = this.getContentResolver().query(selectedImage,
					filePathColumns, null, null, null);
			c.moveToFirst();
			int columnIndex = c.getColumnIndex(filePathColumns[0]);
			String picturePath = c.getString(columnIndex);
			c.close();
			Intent intent = new Intent(this, LengthMeasureActivity.class);
			intent.putExtra("picturePath", picturePath);
			intent.putExtra("unit", selection.getUnit());
			intent.putExtra("length", selection.getLength());
			intent.putExtra("name", selection.getName());
			startActivity(intent);
		}
		if ((requestCode == CAMERA) && (resultCode == Activity.RESULT_OK)) {

			Bundle bundle = data.getExtras();
			Bitmap bitmap = (Bitmap) bundle.get("data");
			Intent intent = new Intent(this, LengthMeasureActivity.class);
			intent.putExtra("bitmap", bitmap);
			intent.putExtra("unit", selection.getUnit());
			intent.putExtra("length", selection.getLength());
			intent.putExtra("name", selection.getName());
			startActivity(intent);
		}
	}

	/**
	 * Activity中按钮的点击事件监听
	 */
	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.btn_division_select: // “请选择参照物被单机”
			items = ListTools.getInfosFromList(selections); // 调用工具类拿到字符串数组
			AlertDialog.Builder build = new Builder(this); // 创建对话框
			build.setTitle("请选择参照物");
			build.setSingleChoiceItems(items, position, this); // 单选对话框
			build.setPositiveButton("确定", this);
			build.setNegativeButton("取消", this);
			build.setNeutralButton("新增", this);
			build.show();
			break;
		case R.id.ib_division_file:
			Intent intent_file = new Intent(
					Intent.ACTION_PICK,
					android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
			startActivityForResult(intent_file, PICTURE);
			break;
		case R.id.ib_division_camera:
			Intent intent_camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(intent_camera, CAMERA);

			break;
		}
	}

	/**
	 * 对话框的点击事件监听（包括选项按钮与确定取消按钮）
	 */
	@Override
	public void onClick(DialogInterface dialog, int which) {

		if (which < 0) {
			switch (which) {
			case -1:// "确定"被点击
				if (dialog.equals(inDialog)) { // 被点击的是第二个对话框
					Division_Selection add_selection = view.getAddItem(); // 拿到对话框内用户输入的信息
					if (add_selection != null) { // 输入正确
						selections.add(add_selection); // 在选项列表中加入加入的选项
						position = selections.indexOf(add_selection);// 设置position为加入数据的位置
						selection = selections.get(position);
						tv_division_select.setText(add_selection.toString());// textview显示选项信息
						SerializerTools.addToLocal(this, selections); // 利用工具类写入数据到本地
						DialogTools.closeDialog(inDialog); // 关闭对话框
					} else { // 输入不合法
						Toast.makeText(this, "请正确输入", 0).show();
						DialogTools.unCloseDialog(inDialog);
					}
				} else {// 被点击的是第一个对话框
					position = temp; // 设置position为选中的位置
					selection = selections.get(position);
					tv_division_select.setText(selection.toString()); // textview显示选项信息
				}
				break;
			case -2:// // "取消被点击，使对话框消失
				DialogTools.closeDialog((Dialog) dialog);
				break;
			case -3:// 新增被点击，显示新增对话框
				AlertDialog.Builder build = new Builder(this);
				build.setTitle("请输入名称,长度，单位");
				build.setPositiveButton("确定", this);
				build.setNegativeButton("取消", this);
				view = new InDialogView(this, null);  // 自定义的对话框VIEW
				build.setView(view); // 设置对话框的view
				inDialog = build.create();
				inDialog.show();
				break;
			}
		} else { // 对话框的子条目被点击
			temp = which; // 缓存点击的条目位置
		}

	}

}
