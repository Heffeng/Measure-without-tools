package com.sixgo.measure.length.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.xmlpull.v1.XmlSerializer;

import android.content.Context;
import android.os.Environment;
import android.util.Xml;
import android.widget.Toast;

import com.sixgo.measure.length.entries.Division_Selection;


/***
 * 序列化xml文件，用于存储选项数据
 *
 * @author Administrator
 *
 */
public class SerializerTools {

	public static void addToLocal(Context context,
								  List<Division_Selection> selections) {
		//判断sd卡是否可用
		if (Environment.getExternalStorageState() == Environment.MEDIA_UNMOUNTED) {
			Toast.makeText(context, "请安装SD卡", 0).show();
			return;
		}
		//拿到序列化工具
		XmlSerializer serializer = Xml.newSerializer();
		try {
			// 先要创建文件夹，然后创建文件，及输入流
			File file = new File(Environment.getExternalStorageDirectory()
					+ "/measures");
			file.mkdir();
			serializer.setOutput(new FileOutputStream(
					new File(file, "data.xml")), "utf-8");

			serializer.startDocument("utf-8", true);
			serializer.startTag(null, "selections");
			for (Division_Selection selection : selections) {
				serializer.startTag(null, "selection");

				serializer.startTag(null, "name");
				serializer.text(selection.getName());
				serializer.endTag(null, "name");

				serializer.startTag(null, "length");
				serializer.text(selection.getLength());
				serializer.endTag(null, "length");

				serializer.startTag(null, "unit");
				serializer.text(selection.getUnit());
				serializer.endTag(null, "unit");

				serializer.endTag(null, "selection");
			}
			serializer.endTag(null, "selections");
			serializer.endDocument();
			Toast.makeText(context, "加入成功", 0).show();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			Toast.makeText(context, "加入错误，存储失败", 0).show();
			e.printStackTrace();
		}
	}

}
