package com.sixgo.measure.length.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.content.Context;
import android.os.Environment;
import android.util.Xml;

import com.sixgo.measure.R;
import com.sixgo.measure.length.entries.Division_Selection;
/**
 * 解析xml文件工具类
 * @author Administrator
 *
 */
public class AnalyzeTools {

	private static XmlPullParser parser;

	public static List<Division_Selection> analyzeSelectionFromXml(
			Context context) {
		File file = new File(Environment.getExternalStorageDirectory()+"/measures/data.xml");
		if (file.exists()) {         //判断文件是否存在
			parser = Xml.newPullParser();  ///存在，就新建xml解析器解析sd卡Xml文件
			try {
				parser.setInput(new FileInputStream(file), "utf-8");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (XmlPullParserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {             //不存在，解析资源文件
			parser = context.getResources().getXml(R.xml.selections);
		}
		///解析，拿到数据
		List<Division_Selection> selections = null;
		try {
			int event = parser.getEventType();
			String name;
			Division_Selection selection = null;
			while (event != XmlPullParser.END_DOCUMENT) {
				switch (event) {
					case XmlPullParser.START_DOCUMENT:
						selections = new ArrayList<Division_Selection>();
						break;
					case XmlPullParser.START_TAG:
						name = parser.getName();
						if ("selection".equals(name)) {
							selection = new Division_Selection();
						} else if ("name".equals(name)) {
							selection.setName(parser.nextText());
						} else if ("length".equals(name)) {
							selection.setLength(parser.nextText());
						} else if ("unit".equals(name)) {
							selection.setUnit(parser.nextText());
						}
						break;
					case XmlPullParser.END_TAG:
						name = parser.getName();
						if ("selection".equals(name)) {
							selections.add(selection);
							selection = null;
						}
						break;
				}
				event = parser.next();
			}
			return selections;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	// public static int getPositionFromListByName(List<Division_Selection>
	// selections,String name){
	// for (Division_Selection division_Selection : selections) {
	// if(division_Selection.getName().equals(name)){
	// return selections.indexOf(division_Selection);
	// }
	// }
	// return 0;
	// }
}
