package com.sixgo.measure.length.utils;

import java.lang.reflect.Field;

import android.app.Dialog;

public class DialogTools {
	/**
	 * 关闭对话框
	 * @param dialog
	 */
	public static void closeDialog(Dialog dialog){
		//关闭对话框
		try {
			Field field = dialog.getClass().getSuperclass().getDeclaredField("mShowing");
			field.setAccessible(true);
			field.set(dialog, true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		dialog.dismiss();
	}
	public static void unCloseDialog(Dialog dialog){
		try {
			//不关闭
			Field field = dialog.getClass().getSuperclass().getDeclaredField("mShowing");
			field.setAccessible(true);
			field.set(dialog, false);
		} catch (Exception e) {
			e.printStackTrace();
		}


	}
}
