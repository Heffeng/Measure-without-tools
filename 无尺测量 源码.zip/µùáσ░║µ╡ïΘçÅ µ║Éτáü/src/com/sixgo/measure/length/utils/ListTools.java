package com.sixgo.measure.length.utils;

import java.util.List;

import com.sixgo.measure.length.entries.Division_Selection;


public class ListTools {

	public static String getInfoFromListByposition(List<Division_Selection> selections,int position){
		Division_Selection  selection = selections.get(position);
		return selection.toString();		
	}
	public static String[] getInfosFromList(List<Division_Selection> selections){
		String[] items = new String[selections.size()];
		Division_Selection  selection;
		for (int i = 0; i < selections.size(); i++) {
			selection = selections.get(i);
			items[i] = selection.toString();
		}
		return items;
		
	}
}
