package com.sixgo.measure.length.entries;

public class Division_Selection {
	@Override
	public String toString() {
		return name + ":" + length + unit;
	}

	public Division_Selection() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String name;
	private String length;
	private String unit;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLength() {
		return length;
	}

	public void setLength(String length) {
		this.length = length;
	}

	public Division_Selection(String name, String length, String unit) {
		super();
		this.name = name;
		this.length = length;
		this.unit = unit;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}
}
