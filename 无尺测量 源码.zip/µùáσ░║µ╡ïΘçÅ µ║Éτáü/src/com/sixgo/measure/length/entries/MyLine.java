package com.sixgo.measure.length.entries;

import java.util.HashMap;

public class MyLine {
	@Override
	public String toString() {
		return "MyLine [p_head=" + p_head.toString() + ", p_tail=" + p_tail.toString() + ", angle="
				+ angle + ", length=" + length + "]";
	}

	private MyPoint p_head;
	private MyPoint p_tail;
	private float a;
	private float b;
	private float c;
	private double angle;
	private double length;

	public MyPoint getMidPoint() {
		MyPoint midPoint = new MyPoint((p_head.getX() + p_tail.getX()) / 2,
				(p_head.getY() + p_tail.getY()) / 2);
		return midPoint;
	}

	public HashMap<String, Float> getPama() {		
		HashMap<String, Float> map = new HashMap<String, Float>();
		map.put("a", a);
		map.put("b", b);
		map.put("c", c);
		return map;
	}

	public float getA() {
		return a;
	}

	public void setA(float a) {
		this.a = a;
	}

	public float getB() {
		return b;
	}

	public void setB(float b) {
		this.b = b;
	}

	public float getC() {
		return c;
	}

	public void setC(float c) {
		this.c = c;
	}

	public double getAngle() {
		return angle;
	}

	public void setAngle(float angle) {
		this.angle = angle;
	}

	public MyPoint getP_head() {
		return p_head;
	}

	public void setP_head(MyPoint p_head) {
		this.p_head = p_head;
	}

	public MyPoint getP_tail() {
		return p_tail;
	}

	public void setP_tail(MyPoint p_tail) {
		this.p_tail = p_tail;
	}

	public MyLine(MyPoint p_head, MyPoint p_tail) {
		super();
		this.p_head = p_head;
		this.p_tail = p_tail;
		init();
	}

	public void init() {
		float p_head_x = p_head.getX();
		float p_head_y = p_head.getY();
		float p_tail_x = p_tail.getX();
		float p_tail_y = p_tail.getY();
		if (p_head_x == p_tail_x) {
			b = 0;
			a = 1;
			c = -p_head_x;
			angle = (float) (Math.PI/2);
		} else if (p_head_y == p_tail_y) {
			a = 0;
			b = 1;
			c = -p_head_y;
			angle = 0;
		} else {
			b = 1;
			a = -((p_tail_y - p_head_y) / (p_tail_x - p_head_x));
			c = -(a * p_head_x) - (b * p_head_y);
			angle = (a<0)? (Math.atan(a)+Math.PI) : Math.atan(a) ;
		}
		this.setLength(Math.sqrt( (p_head_x-p_tail_x)*(p_head_x-p_tail_x) + (p_head_y-p_tail_y)*(p_head_y-p_tail_y)  ));
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}
}
