package com.sixgo.measure.length.ui;

import com.sixgo.measure.R;
import com.sixgo.measure.length.activity.LengthActivity;
import com.sixgo.measure.length.entries.Division_Selection;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * 自定义dialog的view
 *
 * @author Administrator
 *
 */
public class InDialogView extends LinearLayout {

	private EditText et_indialog_unit;
	private EditText et_indialog_length;
	private EditText et_indialog_name;

	public InDialogView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	/**
	 * 初始化view
	 *
	 * @param context
	 */
	private void init(Context context) {
		View view = View.inflate(context, R.layout.indialogview_length, this);
		et_indialog_name = (EditText) view.findViewById(R.id.et_indialog_name);
		et_indialog_length = (EditText) view
				.findViewById(R.id.et_indialog_length);
		et_indialog_unit = (EditText) view.findViewById(R.id.et_indialog_unit);
	}

	/**
	 * 从view中的输入框拿到数据
	 *
	 * @return
	 */
	public Division_Selection getAddItem() {
		String name = et_indialog_name.getText().toString();
		String length = et_indialog_length.getText().toString();
		String unit = et_indialog_unit.getText().toString();
		if (TextUtils.isEmpty(name) || TextUtils.isEmpty(length)
				|| TextUtils.isEmpty(unit)) {
			return null;
		} else
			return new Division_Selection(name, length, unit);

	}
}
