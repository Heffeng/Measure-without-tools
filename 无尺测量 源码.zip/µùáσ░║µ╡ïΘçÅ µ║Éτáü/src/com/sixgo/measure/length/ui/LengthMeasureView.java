package com.sixgo.measure.length.ui;

import com.sixgo.measure.length.entries.MyLine;
import com.sixgo.measure.length.entries.MyPoint;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.widget.ImageView;

public class LengthMeasureView extends ImageView implements OnGestureListener {

	private static final int FUNC_CL_MOVE_HEAD = 0;
	private static final int FUNC_CL_MOVE_LINE = 1;
	private static final int FUNC_CL_MOVE_TAIL = 2;
	private static final int FUNC_WL_MOVE_HEAD = 3;
	private static final int FUNC_WL_MOVE_LINE = 4;
	private static final int FUNC_WL_MOVE_TAIL = 5;
	private com.sixgo.measure.length.entries.MyLine c_l; // 参照物的先
	private com.sixgo.measure.length.entries.MyLine w_l; // 待测物体的线
	private com.sixgo.measure.length.entries.MyPoint first_point;
	private Paint p;
	private Context context;
	private GestureDetector gd;
	double dx;
	double dy;
	private int FUNC_WHICH_POINT;
	public static double division = 1.0;
	public static String name = " 参照物 ";

	public LengthMeasureView(Context context, AttributeSet attrs) {
		super(context, attrs);
		c_l = new MyLine(new MyPoint(200, 200), new MyPoint(200, 600));
		w_l = new MyLine(new MyPoint(500, 200), new MyPoint(500, 800));
		Log.e("c_l", c_l.getLength() + "");
		p = new Paint();
		gd = new GestureDetector(context, this);
		this.context = context;

		first_point = new com.sixgo.measure.length.entries.MyPoint(0, 0);

	}

	/**
	 * 画ImageView
	 */
	public void draw(Canvas canvas) {
		setLine(FUNC_WHICH_POINT);
		division = w_l.getLength() / c_l.getLength();
		p.setStrokeWidth(20);
		drawLine(c_l, canvas);
		drawLine(w_l, canvas);

		p.setTextSize(30);
		drawText(c_l, canvas);
		drawText(w_l, canvas);

	}
	/**
	 * 根据按下的第一个点与两根线的头尾中部的距离
	 * 拿到最小的
	 * 找到要操作的点
	 * @param first_point
	 */
	private void funcWhichPoint(MyPoint first_point) {
		double l[] = { new MyLine(c_l.getP_head(), first_point).getLength(),
				new MyLine(c_l.getMidPoint(), first_point).getLength(),
				new MyLine(c_l.getP_tail(), first_point).getLength(),
				new MyLine(w_l.getP_head(), first_point).getLength(),
				new MyLine(w_l.getMidPoint(), first_point).getLength(),
				new MyLine(w_l.getP_tail(), first_point).getLength() };
		int j = 0;
		for (int i = 1; i < 6; i++) {
			if (l[i] < l[j]) {
				j = i;
			}
		}
		FUNC_WHICH_POINT = j;
	}
	/**
	 * 根据要操作的点设置线
	 * @param whichPoint
	 */
	private void setLine(int whichPoint) {

		switch (whichPoint) {
			case FUNC_CL_MOVE_HEAD:
				//参照物的线   设置头点的位置
				c_l.getP_head().setX((float) (c_l.getP_head().getX() + dx));
				c_l.getP_head().setY((float) (c_l.getP_head().getY() + dy));
				c_l.init();
				break;
			case FUNC_CL_MOVE_LINE:
				c_l.getP_head().setX((float) (c_l.getP_head().getX() + dx));
				c_l.getP_head().setY((float) (c_l.getP_head().getY() + dy));
				c_l.getP_tail().setX((float) (c_l.getP_tail().getX() + dx));
				c_l.getP_tail().setY((float) (c_l.getP_tail().getY() + dy));
				c_l.init();
				break;
			case FUNC_CL_MOVE_TAIL:
				c_l.getP_tail().setX((float) (c_l.getP_tail().getX() + dx));
				c_l.getP_tail().setY((float) (c_l.getP_tail().getY() + dy));
				c_l.init();
				break;

			case FUNC_WL_MOVE_HEAD:
				w_l.getP_head().setX((float) (w_l.getP_head().getX() + dx));
				w_l.getP_head().setY((float) (w_l.getP_head().getY() + dy));
				w_l.init();
				break;
			case FUNC_WL_MOVE_LINE:
				w_l.getP_head().setX((float) (w_l.getP_head().getX() + dx));
				w_l.getP_head().setY((float) (w_l.getP_head().getY() + dy));
				w_l.getP_tail().setX((float) (w_l.getP_tail().getX() + dx));
				w_l.getP_tail().setY((float) (w_l.getP_tail().getY() + dy));
				w_l.init();
				break;
			case FUNC_WL_MOVE_TAIL:
				w_l.getP_tail().setX((float) (w_l.getP_tail().getX() + dx));
				w_l.getP_tail().setY((float) (w_l.getP_tail().getY() + dy));
				w_l.init();
				break;
		}

	}

	/**
	 * 画线
	 *
	 * @param line
	 * @param canvas
	 */
	private void drawLine(MyLine line, Canvas canvas) {

		MyPoint p_head = line.getP_head();
		MyPoint p_tail = line.getP_tail();


		if (line.equals(c_l)) {
			p.setColor(0xffff0000);
		} else {
			p.setColor(0xff00ff00);
		}
		p.setAlpha(0X7e);
		canvas.drawCircle(p_head.getX(), p_head.getY(), 50, p);
		canvas.drawCircle(p_tail.getX(), p_tail.getY(), 50, p);
		p.setAlpha(0Xff);
		canvas.drawLine(p_head.getX(), p_head.getY(), p_tail.getX(),
				p_tail.getY(), p);
	}

	/**
	 * 画文本
	 *
	 * @param line
	 * @param canvas
	 */
	private void drawText(com.sixgo.measure.length.entries.MyLine line, Canvas canvas) {
		MyPoint p_mid = line.getMidPoint();
		if (line.equals(c_l)) {
			p.setColor(0xffff0000);
			canvas.drawText(name, 0, name.length(), p_mid.getX() + 20,
					p_mid.getY() + 20, p);
		} else {
			p.setColor(0xff00ff00);
			canvas.drawText("待测物", 0, 3, p_mid.getX() + 20, p_mid.getY() + 20,
					p);
		}

	}
	/**
	 * 拿到向下按的事件
	 * 拿到第一次按下的坐标
	 * 根据该坐标判断操作的点
	 */

	@Override
	public boolean onDown(MotionEvent e) {
		first_point.setX(e.getX());
		first_point.setY(e.getY());
		funcWhichPoint(first_point);
		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {

	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {

		return false;
	}
	/**
	 * 拿到滚动事件
	 * 根据滚动事件拿到移动的距离
	 * 然后刷新
	 */
	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
							float distanceY) {
		dx = -distanceX;
		dy = -distanceY;
		invalidate();
		return false;
	}

	@Override
	public void onLongPress(MotionEvent e) {

	}

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
						   float velocityY) {

		return false;
	}
	/**
	 * 复写ondraw方法
	 * 在给定的canvas上画图
	 */
	@Override
	protected void onDraw(Canvas canvas) {
		draw(canvas);
		super.onDraw(canvas);
	}
	/**
	 * 从PiantActivity拿到触摸事件
	 * 然后将触摸事件交给 GestureDetector gd 来处理
	 * 必须实现 OnGestureListener 接口
	 */
	@Override
	public boolean onTouchEvent(MotionEvent event) {

		return gd.onTouchEvent(event);
	}
}
