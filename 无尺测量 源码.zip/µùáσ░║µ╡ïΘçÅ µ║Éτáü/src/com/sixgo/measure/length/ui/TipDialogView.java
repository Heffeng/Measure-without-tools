package com.sixgo.measure.length.ui;

import com.sixgo.measure.R;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class TipDialogView extends LinearLayout{

	public TipDialogView(Context context, AttributeSet attrs) {
		super(context, attrs);
		inflate(context, R.layout.indialoview_length, this);
	}

}
