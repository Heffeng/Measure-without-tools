package com.sixgo.measure.angle.ui;

import com.sixgo.measure.angle.entries.Angle;
import com.sixgo.measure.angle.entries.MyLine;
import com.sixgo.measure.angle.entries.MyPoint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.widget.ImageView;

public class AngleMeasureView extends ImageView implements OnGestureListener {

	private static final int FUNC_CL_MOVE_HEAD = 0;
	private static final int FUNC_CL_MOVE_LINE = 1;
	private static final int FUNC_CL_MOVE_TAIL = 2;
	private MyLine c_l; 
	private MyLine w_l; 
	private MyPoint first_point,c_Point;
	private Paint p,p2;
	private Context context;
	private GestureDetector gd;
	double dx;
	double dy;
	private int temp;
	private Angle ang;
	
	
	private double length_3;
	
	public static int angle = 0;
	
	

	public AngleMeasureView(Context context, AttributeSet attrs) {
		super(context, attrs);
		c_Point = new MyPoint(250,700);
		c_l = new MyLine( new MyPoint(250, 400),c_Point);
		w_l = new MyLine(new MyPoint(550, 700),c_Point);
		Log.e("c_l", c_l.getLength() + "");
		p = new Paint();
		p2 = new Paint();
		gd = new GestureDetector(context, this);
		this.context = context;

		first_point = new MyPoint(0, 0);

	
	}

	/**
	 * 画ImageView
	 */
	public void draw(Canvas canvas) {
		setLine(temp);
		
		length_3 = (float) Math.sqrt((w_l.getP_head().getX()-c_l.getP_head().getX())*(w_l.getP_head().getX()-c_l.getP_head().getX()) 
				+(w_l.getP_head().getY()-c_l.getP_head().getY())*(w_l.getP_head().getY()-c_l.getP_head().getY()));
		
		ang = new Angle(w_l.getLength(), c_l.getLength(), length_3);
		angle = ang.getAngle();
		p.setStrokeWidth(13);
		p2.setStrokeWidth(9);
		drawLine(c_l, canvas);
		drawLine(w_l, canvas);


	}
/**
 * 根据按下的第一个点与两根线的头尾中部的距离
 * 拿到最小的
 * 找到要操作的点
 * @param first_point
 */
	private void funcWhichPoint(MyPoint first_point) {
		double l[] = { new MyLine(c_l.getP_head(), first_point).getLength(),
				
				new MyLine(c_l.getP_tail(), first_point).getLength(),
			
				new MyLine(w_l.getP_head(), first_point).getLength() };
		int j = 0;
		for (int i = 1; i <3; i++) {
			if (l[i] < l[j]) {
				j = i;
			}
		}
		temp = j;
	}
private void setLine(int whichPoint) {

		switch (whichPoint) {
		case FUNC_CL_MOVE_HEAD:
			//参照物的线   设置头点的位置
			c_l.getP_head().setX((float) (c_l.getP_head().getX() + dx));
			c_l.getP_head().setY((float) (c_l.getP_head().getY() + dy));
			c_l.init();
			break;
		case FUNC_CL_MOVE_LINE:
			c_l.getP_head().setX((float) (c_l.getP_head().getX() + dx));
			c_l.getP_head().setY((float) (c_l.getP_head().getY() + dy));
			c_l.getP_tail().setX((float) (c_l.getP_tail().getX() + dx));
			c_l.getP_tail().setY((float) (c_l.getP_tail().getY() + dy));
			w_l.getP_head().setX((float) (w_l.getP_head().getX() + dx));
			w_l.getP_head().setY((float) (w_l.getP_head().getY() + dy));
			
			c_Point = c_l.getP_tail();
			
			break;
		case FUNC_CL_MOVE_TAIL:
			w_l.getP_head().setX((float) (w_l.getP_head().getX() + dx));
			w_l.getP_head().setY((float) (w_l.getP_head().getY() + dy));
			w_l.init();
			break;

		}

	}

	
	private void drawLine(MyLine line, Canvas canvas) {
		//画线
		p.setColor(0xff00ff00);
		
		MyPoint p_head = line.getP_head();
		MyPoint p_tail = line.getP_tail();
		canvas.drawLine(p_head.getX(), p_head.getY(), p_tail.getX(),
				p_tail.getY(), p);
		p2.setColor(0xffff0000);
		
		
		p2.setStyle(Paint.Style.STROKE); 	
		canvas.drawCircle(c_Point.getX(), c_Point.getY(), 13, p2);
	}

	/**
	 * 画文本
	 * 
	 * @param line
	 * @param canvas
	 */
	@Override
	public boolean onDown(MotionEvent e) {
		first_point.setX(e.getX()); //第一次按下的坐标
		first_point.setY(e.getY());
		funcWhichPoint(first_point);
		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {

	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {

		return false;
	}


 
 
	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		dx = -distanceX; //手指滑动距离
		dy = -distanceY;
		invalidate();  //刷新
		return true;
	}

	@Override
	public void onLongPress(MotionEvent e) {

	}

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		
		return false;
	}

 //复写onDraw方法
	@Override
	protected void onDraw(Canvas canvas) {
		draw(canvas);
		super.onDraw(canvas);
	}
/**
 * 从PiantActivity拿到触摸事件
 * 然后将触摸事件交给 GestureDetector gd 来处理
 * 必须实现 OnGestureListener 接口
 */
	@Override
	public boolean onTouchEvent(MotionEvent event) {

		return gd.onTouchEvent(event);
	}

  
	
}
