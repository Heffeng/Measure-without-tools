package com.sixgo.measure.angle.entries;



public class Angle {


	private double length_1, length_2, length_3;
	private double cos;
	private double temp;
	
	public Angle(double length_1,double length_2,double length_3){
		this.length_1 = length_1;
		this.length_2 = length_2;
		this.length_3 = length_3;
	}
	
	public int getAngle(){
		

		cos =  (((this.length_1*this.length_1)+(this.length_2*this.length_2)-(this.length_3*this.length_3))/(2*this.length_1*this.length_2));
		temp =   Math.acos(cos);
		
		return  (int) (57.7*temp);
		
		
	}
}
