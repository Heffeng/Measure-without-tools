package com.sixgo.measure.angle.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class ShotScreenTools {

	private static final String TAG = "shotscreen";
	protected static final int TOAST_PRINT = 0;
	private static Thread thread;

	private static Bitmap takeScreenShot(Activity activity) {
		View view = activity.getWindow().getDecorView();
		view.setDrawingCacheEnabled(true);
		view.buildDrawingCache();
		Bitmap bitmap = view.getDrawingCache();
		Rect rect = new Rect();
		activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
		int statusBarHeight = rect.top;
		System.out.println(statusBarHeight);

		int width = activity.getWindowManager().getDefaultDisplay().getWidth();
		int height = activity.getWindowManager().getDefaultDisplay()
				.getHeight();

		Bitmap bitmap2 = Bitmap.createBitmap(bitmap, 0, statusBarHeight, width,
				height - statusBarHeight);
		view.destroyDrawingCache();
		return bitmap2;
	}

	private static void savePic(Bitmap bitmap, String filename) {
		FileOutputStream fileOutputStream = null;
		try {
			fileOutputStream = new FileOutputStream(filename);
			if (fileOutputStream != null) {
				bitmap.compress(Bitmap.CompressFormat.PNG, 90, fileOutputStream);
				fileOutputStream.flush();
				fileOutputStream.close();
			}
		} catch (FileNotFoundException e) {
			Log.d(TAG, "Exception:FileNotFoundException");
			e.printStackTrace();
		} catch (IOException e) {
			Log.d(TAG, "IOException:IOException");
			e.printStackTrace();
		}
	}

	public static void shoot(final Activity a) {

		final File file = new File(Environment.getExternalStorageDirectory()
				+ "/measures/screenshot");
		file.mkdir(); // 同样要先创建文件夹
		if (thread != null && thread.isAlive()) {
			Toast.makeText(a, "正在为您保存，不要频繁操作哦", 0).show();
			return;
		}
		final Handler handler = new Handler() {
			public void handleMessage(Message msg) {
				if (msg.what == TOAST_PRINT) {
					Toast.makeText(a, "已保存至" + file.getAbsolutePath() + "目录下",
							0).show();
				}
			}
		};
		Toast.makeText(a, "请稍候，正在为您保存", 0).show();
		thread = new Thread(new Runnable() {
			@Override
			public void run() {

				ShotScreenTools.savePic(
						ShotScreenTools.takeScreenShot(a),
						file.getAbsolutePath() + "/"
								+ System.currentTimeMillis() + ".jpg");
				Message m = new Message();
				m.what = TOAST_PRINT;
				handler.sendMessage(m);

			}
		});
		thread.start();

	};
}
