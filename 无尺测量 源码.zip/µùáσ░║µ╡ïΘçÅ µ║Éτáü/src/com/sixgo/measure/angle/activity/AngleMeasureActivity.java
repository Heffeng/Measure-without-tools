package com.sixgo.measure.angle.activity;


import com.sixgo.measure.R;
import com.sixgo.measure.angle.ui.AngleMeasureView;
import com.sixgo.measure.angle.utils.ShotScreenTools;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class AngleMeasureActivity extends Activity {
	private ImageView iv_paint_image;
	private ImageView iv_paint_canvasview;
	private TextView tv_angle;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_angle_measure);
		iv_paint_image = (ImageView) findViewById(R.id.iv_paint_image);
		iv_paint_canvasview = (ImageView) findViewById(R.id.iv_paint_canvasview);
		tv_angle = (TextView) findViewById(R.id.tv_paint_length);

		Intent intent = getIntent();
		String picturePath = intent.getStringExtra("picturePath");
		Bitmap bitmap;
		if (TextUtils.isEmpty(picturePath))
			bitmap = intent.getParcelableExtra("bitmap");
		else
			// 背景图
			bitmap = BitmapFactory.decodeFile(picturePath);
		

		Matrix m  = new Matrix();
		int width = bitmap.getWidth();
		int heigth = bitmap.getHeight();
		if (width > heigth) {
			m.postRotate(90);
		}
		Bitmap tempBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, heigth, m,
				false);
		iv_paint_image.setImageBitmap(tempBitmap);
	}

 //拿到这个activity的触摸事件, 将其交给iv_paint_canvasview处理
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		tv_angle.setText("## "
				+ (AngleMeasureView.angle)  +  " 度##");
		return iv_paint_canvasview.onTouchEvent(event);
	}

 //截图并保存

	public void screenShot(View v) {		
		if (Environment.getExternalStorageState() == Environment.MEDIA_UNMOUNTED) {
			Toast.makeText(this, "请安装SD卡", 0).show();
			return;
 	} else {
			ShotScreenTools.shoot(AngleMeasureActivity.this);
		}
	}
}
