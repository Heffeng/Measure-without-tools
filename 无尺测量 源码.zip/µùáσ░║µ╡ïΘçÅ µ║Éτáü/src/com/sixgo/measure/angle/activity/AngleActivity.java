package com.sixgo.measure.angle.activity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

import com.sixgo.measure.R;
import com.sixgo.measure.angle.utils.MyCrashHandler;


public class AngleActivity extends Activity implements OnClickListener
		{
	private static final int PICTURE = 0;
	private static final int CAMERA = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_angle);
		
		
		MyCrashHandler.instance().init();
		ImageButton ib_division_file = (ImageButton) findViewById(R.id.ib_division_file);
		ib_division_file.setOnClickListener(this);
		ImageButton ib_division_camera = (ImageButton) findViewById(R.id.ib_division_camera);
		ib_division_camera.setOnClickListener(this);
		
	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == PICTURE) {
			if (data == null)
				return;
			Uri selectedImage = data.getData();
			String[] filePathColumns = { MediaStore.Images.Media.DATA };
			Cursor c = this.getContentResolver().query(selectedImage,
					filePathColumns, null, null, null);
			c.moveToFirst();
			int columnIndex = c.getColumnIndex(filePathColumns[0]);
			String picturePath = c.getString(columnIndex);
			c.close();
			
			Intent intent = new Intent(this, AngleMeasureActivity.class);
			intent.putExtra("picturePath", picturePath);
			startActivity(intent);
		}
		if ((requestCode == CAMERA) && (resultCode == Activity.RESULT_OK)) {

			Bundle bundle = data.getExtras();
			Bitmap bitmap = (Bitmap) bundle.get("data");
			Intent intent = new Intent(this, AngleMeasureActivity.class);
			intent.putExtra("bitmap", bitmap);
			startActivity(intent);
		}
	}

			/**
			 * Activity中按钮的点击事件监听
			 */
	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.ib_division_file:
			Intent intent_file = new Intent(
					Intent.ACTION_PICK,
					android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
			startActivityForResult(intent_file, PICTURE);
			break;
		case R.id.ib_division_camera:
			Intent intent_camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(intent_camera, CAMERA);

			break;
		}
	}
}
