package com.sixgo.measure;

import com.sixgo.measure.angle.activity.AngleActivity;
import com.sixgo.measure.distance.activity.DistanceActivity;
import com.sixgo.measure.length.activity.LengthActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;

public class HomeActivity extends Activity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			AlertDialog.Builder builder = new Builder(this);
			builder.setTitle("退出").setMessage("是否退出")
					.setPositiveButton("确定", this)
					.setNegativeButton("取消", this).create().show();
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		switch (which) {
			case -1:
				Intent startMain = new Intent(Intent.ACTION_MAIN);

				startMain.addCategory(Intent.CATEGORY_HOME);

				startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

				startActivity(startMain);

				android.os.Process.killProcess(android.os.Process.myPid());

				break;
			case -2:
				dialog.dismiss();
		}

	}

	public void angle(View v) {
		startActivity(new Intent(this, AngleActivity.class));
	}

	public void division(View v) {
		startActivity(new Intent(this, LengthActivity.class));
	}

	public void distance(View v) {
		startActivity(new Intent(this, DistanceActivity.class));
	}
	public void about(View v) {

	}
}