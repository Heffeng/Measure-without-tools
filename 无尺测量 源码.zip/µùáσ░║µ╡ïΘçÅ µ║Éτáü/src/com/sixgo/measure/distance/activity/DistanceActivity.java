package com.sixgo.measure.distance.activity;

import java.text.NumberFormat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.sixgo.measure.R;
import com.sixgo.measure.distance.camera.CameraView;
import com.sixgo.measure.distance.ui.SetHeightDiaView;
import com.sixgo.measure.distance.utils.MyCrashHandler;

public class DistanceActivity extends Activity implements OnClickListener,
		android.content.DialogInterface.OnClickListener {

	private static float et_divice_height = (float) 1.5;
	//设置高度的对话框
	private SetHeightDiaView shdv;
	// 显示距离的文本
	private static TextView tv_distance;
	// 显示高度的文本
	private static TextView tv_height;
	/**
	 * 测量按钮下的文本 { 计算距离 , 重新计算距离 , 重新测量 }
	 */
	private static TextView tv_caculate;
	// 告知用户是否测量高度的布局
	private LinearLayout ll_calulate_heihght;
	// 显示高度的布局
	private LinearLayout ll_height;

	// 正在测量距离
	private static final int IS_MEASURING_DISTANCE = 1;
	// 正在计算距离
	private static final int IS_CACULATING_DISTANCE = 2;
	// 正在测量高度
	private static final int IS_MEASURING_HEIGHT = 3;
	// 正在计算高度
	private static final int IS_CACULATING_HEIGHT = 4;
	// 正在计算高度
	private static int state;
	// 测量的距离
	private static double distance;
	// 测量的高度
	private static double height;
	private static NumberFormat format;

	/**
	 * 拿到从BanlaceBall传来的传感器信息 ,计算出手机距离待测物的距离
	 *
	 * @param f1
	 *            方向传感器信息
	 * @param f2
	 *            重力传感器信息
	 */
	public static void showDistance(float[] f1, float[] f2) {
		//不在等待计算距离，停止showDistance（）
		if (state != IS_MEASURING_DISTANCE )
			return;
		float fz1 = f1 == null ? 0 : f1[2];
		float fz2 = (float) (f2 == null ? 9.8 : f2[2]);
		if (fz1 > 0 && fz1 < 90) {
			distance = et_divice_height * Math.tan(fz1 * Math.PI / 180);
			tv_distance.setText(format.format(distance) + "米");
		}
		if (fz2 <= 0) {
			tv_distance.setText("最大");
		}

	};

	/**
	 * 拿到从BanlaceBall传来的传感器信息 ,计算出手机距离待测物的高度
	 *
	 * @param f1
	 *            方向传感器信息
	 * @param f2
	 *            重力传感器信息
	 */
	public static void showHeight(float[] f1, float[] f2) {
		// 计算高度，停止showDistance（）
		if (state != IS_MEASURING_HEIGHT)
			return;
		float fz1 = f1[2];
		float fz2 = (float) (f2 == null ? 9.8 : f2[2]);
		if (fz2 < 0) {
			fz1 = 180 - fz1;
		}

		height = et_divice_height - distance
				* Math.tan(Math.PI / 2 - fz1 * Math.PI / 180);
		tv_height.setText(format.format(height) + "米");

	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_distance);
		MyCrashHandler.instance().init();
		state = 1;
		/**
		 * 创建一个自定义相机视图，绑定在传进来的surfaceView上
		 */
		new CameraView(this, (SurfaceView) findViewById(R.id.sv));

		/**
		 * 初始化界面的按钮，并注册监听
		 */
		ImageButton btn_setHeight = (ImageButton) findViewById(R.id.btn_setHeight);
		btn_setHeight.setOnClickListener(this);

		ImageButton btn_caculate = (ImageButton) findViewById(R.id.btn_caculate);
		btn_caculate.setOnClickListener(this);

		ImageButton btn_caculate_height = (ImageButton) findViewById(R.id.btn_caculate_height);
		btn_caculate_height.setOnClickListener(this);

		/**
		 * 初始化界面的TextView
		 */
		tv_caculate = (TextView) findViewById(R.id.tv_caculate);

		tv_distance = (TextView) findViewById(R.id.tv_distance);

		tv_height = (TextView) findViewById(R.id.tv_height);

		/**
		 * 初始化要控制显示及隐藏的布局
		 */
		ll_calulate_heihght = (LinearLayout) findViewById(R.id.ll_calulate_heihght);

		ll_height = (LinearLayout) findViewById(R.id.ll_height);

		format = NumberFormat.getInstance();
		format.setMaximumFractionDigits(1);
		format.setMinimumFractionDigits(1);

	}

	/**
	 * 点击界面按钮时的回调方法 测量 动态显示 计算 静态显示
	 */
	@Override
	public void onClick(View v) {
		switch (v.getId()) {

			// 设置设备高度的按钮点击
		case R.id.btn_setHeight:
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			// 新建一个对话框视图
			shdv = new SetHeightDiaView(this, null);
			// 创键对话框，并设置“确定”，“取消”按钮，设置对话框视图为shdv
			builder.setCancelable(false).setView(shdv)
					.setPositiveButton("确定", this)
					.setNegativeButton("取消", this).show();
			// 设置shdv中文本框内容
			shdv.setEtDivice(et_divice_height);

			break;

			// 计算按钮的点击事件
		case R.id.btn_caculate:
			switch (state) {
				/**
				 * 是在测量距离，点击计算距离
				 */
			case IS_MEASURING_DISTANCE:
				state = IS_CACULATING_DISTANCE;
				tv_caculate.setText("重新计算距离");
				ll_calulate_heihght.setVisibility(View.VISIBLE);
				break;
				/**
				 * 是在计算距离，点击重新测量距离
				 */
			case IS_CACULATING_DISTANCE:
				state = IS_MEASURING_DISTANCE;
				ll_calulate_heihght.setVisibility(View.GONE);
				tv_caculate.setText("计算距离");
				break;
				/**
				 * 是在测量高度点击计算高度
				 */
			case IS_MEASURING_HEIGHT:
				state = IS_CACULATING_HEIGHT;
				tv_caculate.setText("重新测量");

				break;
				/**
				 * 是在计算高度，点击重新测量
				 */
			case IS_CACULATING_HEIGHT:
				state = IS_MEASURING_DISTANCE;
				ll_height.setVisibility(View.GONE);
				tv_caculate.setText("计算距离");
				break;

			}

			break;
			// 是否测量高度按钮的点击事件

		case R.id.btn_caculate_height:

			state = IS_MEASURING_HEIGHT;

			ll_calulate_heihght.setVisibility(View.GONE);
			ll_height.setVisibility(View.VISIBLE);
			tv_caculate.setText("计算高度");

			break;

		}

	}

	/**
	 * 点击对话框里按钮时的回调方法
	 */
	@Override
	public void onClick(DialogInterface dialog, int which) {
		switch (which) {
			// 确定被点击，设置设备高度为用户输入的高度
		case -1:
			et_divice_height = shdv.getEtDiviceHeight();
			break;
		default:
			dialog.dismiss();
		}
	}

}
