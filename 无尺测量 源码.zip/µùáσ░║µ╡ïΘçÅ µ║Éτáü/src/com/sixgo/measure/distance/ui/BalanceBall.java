package com.sixgo.measure.distance.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.sixgo.measure.distance.activity.DistanceActivity;

/**
 * 此类是实现饿了一个平衡球视图 使用到了传感器
 *
 * @author Administrator
 *
 */
public class BalanceBall extends ImageView {

	private static final String TAG = "BalanceBall";
	private Paint p;
	private int width;
	private int height;
	private float cx;
	private Sensor sensorOri;
	private Sensor sensorAcc;
	public float[] f1;
	public float[] f2;
	private SensorEventListener sensorListener;
	private SensorManager sm;
//	private PrintStream printStream;

	public BalanceBall(Context context, AttributeSet attrs) {
		super(context, attrs);
		sm = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
		p = new Paint();
		p.setColor(0Xff000000);
		sensorListener = new Listener();
		initOrientationSensor();
		initGravitySensor();
	}

	@Override
	protected void onDetachedFromWindow() {
		sm.unregisterListener(sensorListener);
//		printStream.close();
		super.onDetachedFromWindow();
	}

	@Override
	protected void onDraw(Canvas canvas) {


		super.onDraw(canvas);
		width = this.getWidth();
		height = this.getHeight();
		float f = (f1 == null) ? 0 : f1[1];
		if (Math.abs(f) > 90) {
			f = f > 0 ? 180 - f : -180 - f;
		}
		cx = width / 2 - f * 3;
		if (cx > width - 70) {
			cx = width - 70;
		} else if (cx < 70) {
			cx = 70;
		}
		canvas.drawCircle(cx, height / 2, 20, p);
//		FileOutputStream fileOutputStream;
//		try {
//			fileOutputStream = new FileOutputStream(
//					new File(Environment.getExternalStorageDirectory(),
//							"MyLog1.txt"), true);
//			printStream = new PrintStream(fileOutputStream);
//			printStream.println(TAG+"...cx:"+cx);
//			
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}

	/**
	 * 初始化方向传感器
	 */
	private void initOrientationSensor() {
		sensorOri = sm.getDefaultSensor(Sensor.TYPE_ORIENTATION);
		sm.registerListener(sensorListener, sensorOri,
				SensorManager.SENSOR_DELAY_GAME);
	}
	/**
	 * 初始化重力传感器
	 */
	private void initGravitySensor() {
		sensorAcc = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
		sm.registerListener(sensorListener, sensorAcc,
				SensorManager.SENSOR_DELAY_GAME);
	}

	/**
	 * 内部类实现传感事件监听器接口
	 *
	 * @author Administrator
	 *
	 */
	private class Listener implements SensorEventListener {

		@Override
		public void onSensorChanged(SensorEvent event) {

			if (event.sensor == sensorOri) {
				f1 = event.values;
			}
			if (event.sensor == sensorAcc) {
				f2 = event.values;
			}
			DistanceActivity.showDistance(f1, f2);
			DistanceActivity.showHeight(f1, f2);
			invalidate();
		}

		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {

		}
	}
}
