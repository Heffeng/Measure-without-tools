package com.sixgo.measure.distance.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.sixgo.measure.R;

/**
 * 设置高度对话框的布局视图
 *
 * @author Administrator
 *
 */
public class SetHeightDiaView extends LinearLayout {

	private EditText et_divice_height;

	public SetHeightDiaView(Context context, AttributeSet attrs) {
		super(context, attrs);
		View view = inflate(context, R.layout.set_height_dia_distance, this);
		et_divice_height = (EditText) view.findViewById(R.id.et_divice_height);
	}

	/**
	 * 拿到用户在对话框文本中输入的数据
	 *
	 * @return 设备高度
	 */
	public float getEtDiviceHeight() {
		return Float.parseFloat(et_divice_height.getText().toString().trim());
	}

	/**
	 * 对话框被打开时，设置对话框中文本框的内容为用户习惯使用高度
	 * @param height  用户习惯使用高度
	 */
	public void setEtDivice(float height) {
		et_divice_height.setText(height + "");
	}
}
