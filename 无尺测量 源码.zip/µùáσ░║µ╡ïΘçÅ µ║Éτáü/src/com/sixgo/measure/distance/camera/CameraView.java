package com.sixgo.measure.distance.camera;

import java.io.IOException;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.widget.Toast;

/**
 * 相机预览类
 *
 * @author Administrator
 *
 */
public class CameraView {

	private SurfaceHolder holder;
	private Camera camera;

	/**
	 * 创建一个自定义相机视图，绑定在传进来的surfaceView上
	 *
	 * @param context
	 * @param surfaceView
	 */
	public CameraView(final Context context, SurfaceView surfaceView) {
		if (!checkCamera(context)) {
			Toast.makeText(context, "没有找到摄像头", 0).show();
			return;
		}

		// 拿到surfaceView的holder
		holder = surfaceView.getHolder();
		// 拿到holder被调用和销毁的毁掉事件
		holder.addCallback(new Callback() {
			/**
			 * 销毁时释放资源
			 */
			@Override
			public void surfaceDestroyed(SurfaceHolder arg0) {
				camera.stopPreview();
				camera.release();
				camera = null;
			}

			@Override
			public void surfaceCreated(SurfaceHolder arg0) {
				try {
					if ((camera = getCameraInstance(context)) == null)
						return;
					camera.setPreviewDisplay(holder);
					camera.startPreview();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}

			@Override
			public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2,
					int arg3) {

			}
		});

	}

	/**
	 * 拿到系统相机的实例
	 *
	 * @param context
	 * @return 返回相机实例
	 */
	private Camera getCameraInstance(Context context) {
		Camera camera = null;
		try {
			camera = Camera.open();
		} catch (Exception e) {
			Toast.makeText(context, "摄像头被占用，请关闭其他使用相机的程序", 0).show();
		}
		return camera;
	}

	/**
	 * 判断是否有摄像头
	 *
	 * @param context
	 * @return
	 */
	private boolean checkCamera(Context context) {
		if (context.getPackageManager().hasSystemFeature(
				PackageManager.FEATURE_CAMERA)) {
			return true;
		}
		return false;
	}
}
